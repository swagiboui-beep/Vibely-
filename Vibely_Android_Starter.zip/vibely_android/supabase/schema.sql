-- Vibely database setup. Run the whole file in Supabase SQL Editor.
-- Enable RLS on all user data; never put a service-role key in the mobile app.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Vibely member',
  username text unique,
  bio text not null default '',
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text not null default '',
  image_url text,
  created_at timestamptz not null default now(),
  constraint post_has_content check (length(trim(caption)) > 0 or image_url is not null)
);

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (length(trim(content)) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  constraint follows_not_self check (follower_id <> following_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (length(trim(content)) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_user_id_idx on public.posts(user_id);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

create policy "Profiles are readable by signed-in users" on public.profiles for select to authenticated using (true);
create policy "Users create their own profile" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "Users update their own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "Signed-in users read posts" on public.posts for select to authenticated using (true);
create policy "Users create own posts" on public.posts for insert to authenticated with check (user_id = auth.uid());
create policy "Authors update own posts" on public.posts for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "Authors delete own posts" on public.posts for delete to authenticated using (user_id = auth.uid());

create policy "Signed-in users read likes" on public.likes for select to authenticated using (true);
create policy "Users like as themselves" on public.likes for insert to authenticated with check (user_id = auth.uid());
create policy "Users remove own likes" on public.likes for delete to authenticated using (user_id = auth.uid());

create policy "Signed-in users read comments" on public.comments for select to authenticated using (true);
create policy "Users create comments as themselves" on public.comments for insert to authenticated with check (user_id = auth.uid());
create policy "Users delete own comments" on public.comments for delete to authenticated using (user_id = auth.uid());

create policy "Signed-in users read follows" on public.follows for select to authenticated using (true);
create policy "Users follow as themselves" on public.follows for insert to authenticated with check (follower_id = auth.uid());
create policy "Users unfollow as themselves" on public.follows for delete to authenticated using (follower_id = auth.uid());

-- Security-definer membership check avoids recursive RLS policies on conversation_members.
create or replace function public.is_conversation_member(target_conversation_id uuid, target_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = target_conversation_id and cm.user_id = target_user_id
  );
$$;
revoke all on function public.is_conversation_member(uuid, uuid) from public;
grant execute on function public.is_conversation_member(uuid, uuid) to authenticated;

create policy "Members can read their conversations" on public.conversations for select to authenticated
using (public.is_conversation_member(id, auth.uid()));
create policy "Members can read memberships" on public.conversation_members for select to authenticated
using (public.is_conversation_member(conversation_id, auth.uid()));
-- Membership inserts are performed only by the security-definer RPC below.
-- Do not grant clients direct INSERT access to conversation_members.

create policy "Members read conversation messages" on public.messages for select to authenticated
using (public.is_conversation_member(conversation_id, auth.uid()));
create policy "Members send messages as themselves" on public.messages for insert to authenticated
with check (sender_id = auth.uid() and public.is_conversation_member(conversation_id, auth.uid()));

-- New users automatically get a profile row.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', 'Vibely member'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Creates a direct conversation, reusing an existing one between the two users.
create or replace function public.create_conversation_with_user(other_user_id uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  current_id uuid := auth.uid();
  found_id uuid;
begin
  if current_id is null or other_user_id is null or current_id = other_user_id then
    raise exception 'Invalid conversation members';
  end if;
  if not exists (select 1 from public.profiles where id = other_user_id) then
    raise exception 'User not found';
  end if;
  select c.id into found_id
  from public.conversations c
  where exists (select 1 from public.conversation_members a where a.conversation_id = c.id and a.user_id = current_id)
    and exists (select 1 from public.conversation_members b where b.conversation_id = c.id and b.user_id = other_user_id)
    and (select count(*) from public.conversation_members x where x.conversation_id = c.id) = 2
  limit 1;
  if found_id is not null then return found_id; end if;
  insert into public.conversations default values returning id into found_id;
  insert into public.conversation_members (conversation_id, user_id)
  values (found_id, current_id), (found_id, other_user_id);
  return found_id;
end;
$$;
revoke all on function public.create_conversation_with_user(uuid) from public;
grant execute on function public.create_conversation_with_user(uuid) to authenticated;

-- Storage bucket for user-uploaded post photos.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('post-images', 'post-images', true, 10485760, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "Signed-in users upload their own post photos" on storage.objects
for insert to authenticated with check (
  bucket_id = 'post-images' and (storage.foldername(name))[1] = auth.uid()::text
);
create policy "Post photos are publicly viewable" on storage.objects
for select to public using (bucket_id = 'post-images');
create policy "Users delete their own post photos" on storage.objects
for delete to authenticated using (
  bucket_id = 'post-images' and (storage.foldername(name))[1] = auth.uid()::text
);

-- Enable Realtime for live messages. If already in publication, remove this line's effect by skipping it.
alter publication supabase_realtime add table public.messages;
