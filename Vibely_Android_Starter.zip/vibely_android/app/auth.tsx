import { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { supabase, supabaseConfigured } from '../lib/supabase';
import { styles } from '../lib/styles';

export default function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!supabaseConfigured) {
      Alert.alert('Connect Supabase first', 'Follow README.md to create a Supabase project and add its URL and key to .env.');
      return;
    }
    if (!email.trim() || password.length < 8 || (mode === 'signup' && !name.trim())) {
      Alert.alert('Check your details', 'Enter your name (for sign-up), a valid email, and a password of at least 8 characters.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email: email.trim().toLowerCase(),
          password,
          options: { data: { display_name: name.trim() } },
        });
        if (error) throw error;
        Alert.alert('Check your email', 'If email confirmation is enabled, confirm your email before signing in.');
        setMode('login');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
        if (error) throw error;
        router.replace('/(tabs)/feed');
      }
    } catch (e: any) {
      Alert.alert('Could not continue', e.message || 'Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.authWrap}>
        <View style={styles.logo}><Text style={styles.logoText}>V</Text></View>
        <Text style={styles.brand}>Vibely</Text>
        <Text style={styles.subtitle}>Your people. Your moments.</Text>
        <Text style={styles.heading}>{mode === 'signup' ? 'Create your account' : 'Welcome back'}</Text>
        {mode === 'signup' && <TextInput value={name} onChangeText={setName} placeholder="Your name" style={styles.input} autoCapitalize="words" />}
        <TextInput value={email} onChangeText={setEmail} placeholder="Email address" style={styles.input} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} />
        <TextInput value={password} onChangeText={setPassword} placeholder="Password (8+ characters)" style={styles.input} secureTextEntry />
        <Pressable style={[styles.button, busy && { opacity: 0.6 }]} onPress={submit} disabled={busy}>
          <Text style={styles.buttonText}>{busy ? 'Please wait…' : mode === 'signup' ? 'Create account' : 'Sign in'}</Text>
        </Pressable>
        <Pressable onPress={() => setMode(mode === 'signup' ? 'login' : 'signup')} style={{ padding: 14 }}>
          <Text style={styles.link}>{mode === 'signup' ? 'Already have an account? Sign in' : 'New to Vibely? Create an account'}</Text>
        </Pressable>
        <Text style={styles.smallNote}>Real accounts require the Supabase setup described in README.md.</Text>
      </View>
    </KeyboardAvoidingView>
  );
}
