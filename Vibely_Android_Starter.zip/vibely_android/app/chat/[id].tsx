import { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../lib/supabase';
import { styles } from '../../lib/styles';

type Message = { id: string; sender_id: string; content: string; created_at: string; };
export default function ChatScreen() {
  const { id, name } = useLocalSearchParams<{ id: string; name: string }>();
  const [messages, setMessages] = useState<Message[]>([]);
  const [userId, setUserId] = useState('');
  const [draft, setDraft] = useState('');

  const load = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) setUserId(user.id);
    const { data, error } = await supabase.from('messages').select('id,sender_id,content,created_at').eq('conversation_id', id).order('created_at');
    if (error) console.warn(error.message); else setMessages((data || []) as Message[]);
  }, [id]);

  useEffect(() => {
    load();
    const channel = supabase.channel(`chat-${id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${id}` }, payload => {
        setMessages(current => current.some(m => m.id === (payload.new as Message).id) ? current : [...current, payload.new as Message]);
      }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id, load]);

  async function send() {
    if (!draft.trim()) return;
    const { error } = await supabase.from('messages').insert({ conversation_id: id, sender_id: userId, content: draft.trim() });
    if (error) Alert.alert('Message not sent', error.message);
    else { setDraft(''); load(); }
  }

  return <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <Stack.Screen options={{ title: name || 'Chat', headerShown: true }} />
    <FlatList data={messages} keyExtractor={m => m.id} contentContainerStyle={{ padding: 14, gap: 10 }}
      renderItem={({ item }) => <View style={[styles.bubble, { alignSelf: item.sender_id === userId ? 'flex-end' : 'flex-start', backgroundColor: item.sender_id === userId ? '#6D42D8' : '#EEE9F6' }]}><Text style={{ color: item.sender_id === userId ? '#FFFFFF' : '#21163C' }}>{item.content}</Text></View>}
      ListEmptyComponent={<Text style={styles.subtitle}>Say hello to start the conversation.</Text>} />
    <View style={styles.composer}>
      <TextInput value={draft} onChangeText={setDraft} placeholder="Write a message…" style={[styles.input, { flex: 1, marginBottom: 0 }]} />
      <Pressable onPress={send} style={styles.sendButton}><Text style={styles.buttonText}>Send</Text></Pressable>
    </View>
  </KeyboardAvoidingView>;
}
