import { useCallback, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, Pressable, RefreshControl, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { supabase } from '../../lib/supabase';
import { styles } from '../../lib/styles';

type Post = {
  id: string; user_id: string; caption: string; image_url: string | null; created_at: string;
  profiles?: { display_name: string | null; username: string | null; avatar_url: string | null } | null;
  likes?: { user_id: string }[];
};

export default function FeedScreen() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUserId(user?.id ?? null);
    const { data, error } = await supabase.from('posts')
      .select('id,user_id,caption,image_url,created_at,profiles(display_name,username,avatar_url),likes(user_id)')
      .order('created_at', { ascending: false }).limit(50);
    if (error) {
      console.warn(error.message);
      if (!user) Alert.alert('Feed unavailable', 'Sign in and make sure you have run the Supabase SQL setup in README.md.');
    } else setPosts((data || []) as Post[]);
    setLoading(false);
    setRefreshing(false);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function toggleLike(post: Post) {
    if (!userId) return;
    const liked = (post.likes || []).some(l => l.user_id === userId);
    const result = liked
      ? await supabase.from('likes').delete().eq('post_id', post.id).eq('user_id', userId)
      : await supabase.from('likes').insert({ post_id: post.id, user_id: userId });
    if (result.error) Alert.alert('Like failed', result.error.message);
    else load();
  }

  async function signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) Alert.alert('Sign out failed', error.message);
  }

  return (
    <View style={styles.screen}>
      <View style={styles.feedHeader}>
        <View><Text style={styles.brand}>Vibely 💜</Text><Text style={styles.subtitle}>Your people. Your moments.</Text></View>
        <Pressable onPress={signOut}><Text style={styles.link}>Sign out</Text></Pressable>
      </View>
      {loading ? <ActivityIndicator color="#6D42D8" style={{ marginTop: 32 }} /> :
        <FlatList
          data={posts}
          keyExtractor={item => item.id}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor="#6D42D8" />}
          contentContainerStyle={{ padding: 14, paddingBottom: 24, gap: 14 }}
          ListEmptyComponent={<View style={styles.empty}><Text style={styles.heading}>Your feed starts here</Text><Text style={styles.subtitle}>Create the first post using the Post tab.</Text></View>}
          renderItem={({ item }) => {
            const liked = (item.likes || []).some(l => l.user_id === userId);
            return <View style={styles.card}>
              <Text style={styles.postAuthor}>{item.profiles?.display_name || item.profiles?.username || 'Vibely member'}</Text>
              <Text style={styles.postTime}>{new Date(item.created_at).toLocaleString()}</Text>
              {!!item.caption && <Text style={styles.caption}>{item.caption}</Text>}
              {!!item.image_url && <Image source={{ uri: item.image_url }} style={styles.postImage} resizeMode="cover" />}
              <View style={styles.actions}>
                <Pressable onPress={() => toggleLike(item)}><Text style={liked ? styles.liked : styles.actionText}>{liked ? '♥ Liked' : '♡ Like'} · {item.likes?.length || 0}</Text></Pressable>
                <Text style={styles.actionText}>Comments coming next</Text>
              </View>
            </View>;
          }}
        />
      }
    </View>
  );
}
