import { useCallback, useState } from 'react';
import { Alert, FlatList, Pressable, Text, TextInput, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { supabase } from '../../lib/supabase';
import { styles } from '../../lib/styles';

type Conversation = { id: string; other_id: string; display_name: string; last_message: string; };

export default function InboxScreen() {
  const [items, setItems] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [username, setUsername] = useState('');
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const { data, error } = await supabase.from('conversation_members')
      .select('conversation_id, conversations(id, updated_at, messages(content, created_at, sender_id), conversation_members(user_id, profiles(display_name)))')
      .eq('user_id', user.id);
    if (error) {
      console.warn(error.message);
      Alert.alert('Messages unavailable', 'Check that the SQL setup in README.md has been completed.');
      setLoading(false);
      return;
    }
    const rows: Conversation[] = (data || []).map((row: any) => {
      const conv = row.conversations;
      const other = (conv?.conversation_members || []).find((m: any) => m.user_id !== user.id);
      const messages = [...(conv?.messages || [])].sort((a: any, b: any) => a.created_at.localeCompare(b.created_at));
      return { id: conv?.id, other_id: other?.user_id, display_name: other?.profiles?.display_name || 'Vibely member', last_message: messages[messages.length - 1]?.content || 'Say hello!' };
    }).filter(x => x.id);
    setItems(rows);
    setLoading(false);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function newChat() {
    const clean = username.trim().replace(/^@/, '').toLowerCase();
    if (!/^[a-z0-9_]{3,24}$/.test(clean)) {
      Alert.alert('Check username', 'Enter a username with 3–24 letters, numbers, or underscores.');
      return;
    }
    setCreating(true);
    try {
      const { data: other, error } = await supabase.from('profiles').select('id,display_name').eq('username', clean).single();
      if (error || !other) throw new Error('That username was not found. Ask your friend to save their username in Profile first.');
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || user.id === other.id) throw new Error('You cannot start a chat with your own account.');
      const { data: convId, error: createError } = await supabase.rpc('create_conversation_with_user', { other_user_id: other.id });
      if (createError) throw createError;
      setShowNew(false);
      setUsername('');
      router.push({ pathname: '/chat/[id]', params: { id: String(convId), name: other.display_name || clean } });
    } catch (e: any) {
      Alert.alert('Could not start chat', e.message || 'Please try again.');
    } finally {
      setCreating(false);
    }
  }

  return <View style={styles.screen}>
    <View style={{ padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
      <View><Text style={styles.heading}>Private messages</Text><Text style={styles.subtitle}>Chat with people on Vibely.</Text></View>
      <Pressable onPress={() => setShowNew(!showNew)} style={styles.smallPill}><Text style={styles.secondaryButtonText}>{showNew ? 'Cancel' : '＋ New'}</Text></Pressable>
    </View>
    {showNew && <View style={[styles.card, { marginHorizontal: 14, marginBottom: 8 }]}>
      <Text style={styles.postAuthor}>Start a conversation</Text>
      <Text style={styles.subtitle}>Enter your friend's Vibely username.</Text>
      <TextInput value={username} onChangeText={setUsername} autoCapitalize="none" autoCorrect={false} placeholder="friend_username" style={[styles.input, { marginTop: 12 }]} />
      <Pressable onPress={newChat} disabled={creating} style={styles.button}><Text style={styles.buttonText}>{creating ? 'Opening chat…' : 'Start chat'}</Text></Pressable>
    </View>}
    {loading ? <Text style={styles.subtitle}>Loading conversations…</Text> :
      <FlatList data={items} keyExtractor={x => x.id} contentContainerStyle={{ padding: 14, gap: 10 }}
        ListEmptyComponent={<View style={styles.empty}><Text style={styles.heading}>No chats yet</Text><Text style={styles.subtitle}>Tap “New” to start a private conversation.</Text></View>}
        renderItem={({ item }) => <Pressable style={styles.card} onPress={() => router.push({ pathname: '/chat/[id]', params: { id: item.id, name: item.display_name } })}>
          <Text style={styles.postAuthor}>{item.display_name}</Text><Text style={styles.caption}>{item.last_message}</Text>
        </Pressable>} />}
  </View>;
}
