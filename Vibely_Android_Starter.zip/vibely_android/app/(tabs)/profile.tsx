import { useEffect, useState } from 'react';
import { Alert, Pressable, Text, TextInput, View } from 'react-native';
import { supabase } from '../../lib/supabase';
import { styles } from '../../lib/styles';

export default function ProfileScreen() {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.from('profiles').select('display_name,username,bio').eq('id', user.id).single();
      if (data) { setName(data.display_name || ''); setUsername(data.username || ''); setBio(data.bio || ''); }
    })();
  }, []);

  async function save() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const cleanUsername = username.trim().toLowerCase().replace(/^@/, '');
    if (!/^[a-z0-9_]{3,24}$/.test(cleanUsername)) {
      Alert.alert('Choose a username', 'Use 3–24 letters, numbers, or underscores.');
      return;
    }
    const { error } = await supabase.from('profiles').upsert({ id: user.id, display_name: name.trim(), username: cleanUsername, bio: bio.trim() });
    if (error) Alert.alert('Could not save profile', error.message);
    else Alert.alert('Saved', 'Your profile has been updated.');
  }

  return <View style={styles.screen}>
    <View style={{ padding: 16, gap: 14 }}>
      <View style={styles.profileHero}><Text style={{ fontSize: 40 }}>💜</Text><Text style={styles.heading}>{name || 'Your profile'}</Text><Text style={styles.subtitle}>@{username || 'choose_username'}</Text></View>
      <Text style={styles.label}>Display name</Text><TextInput value={name} onChangeText={setName} style={styles.input} placeholder="Your name" />
      <Text style={styles.label}>Username (unique)</Text><TextInput value={username} onChangeText={setUsername} style={styles.input} autoCapitalize="none" placeholder="your_username" />
      <Text style={styles.label}>Bio</Text><TextInput value={bio} onChangeText={setBio} style={[styles.input, styles.multiline]} multiline placeholder="A little about you" />
      <Pressable style={styles.button} onPress={save}><Text style={styles.buttonText}>Save profile</Text></Pressable>
    </View>
  </View>;
}
