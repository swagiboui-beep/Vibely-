import { useState } from 'react';
import { Alert, Image, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { supabase } from '../../lib/supabase';
import { styles } from '../../lib/styles';

export default function ComposeScreen() {
  const [caption, setCaption] = useState('');
  const [image, setImage] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [busy, setBusy] = useState(false);

  async function chooseImage() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Photo permission needed', 'Allow Vibely to access your photos to attach an image.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, quality: 0.8 });
    if (!result.canceled) setImage(result.assets[0]);
  }

  async function publish() {
    if (!caption.trim() && !image) {
      Alert.alert('Add something first', 'Write a caption or choose a photo.');
      return;
    }
    setBusy(true);
    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) throw new Error('Please sign in again.');
      let imageUrl: string | null = null;
      if (image) {
        const response = await fetch(image.uri);
        const blob = await response.blob();
        const ext = (image.fileName?.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '');
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: uploadError } = await supabase.storage.from('post-images').upload(path, blob, {
          contentType: image.mimeType || 'image/jpeg',
          upsert: false,
        });
        if (uploadError) throw uploadError;
        const { data } = supabase.storage.from('post-images').getPublicUrl(path);
        imageUrl = data.publicUrl;
      }
      const { error } = await supabase.from('posts').insert({ user_id: user.id, caption: caption.trim(), image_url: imageUrl });
      if (error) throw error;
      setCaption('');
      setImage(null);
      Alert.alert('Posted!', 'Your post is now on the feed.');
      router.replace('/(tabs)/feed');
    } catch (e: any) {
      Alert.alert('Could not publish', e.message || 'Check your connection and Supabase setup.');
    } finally {
      setBusy(false);
    }
  }

  return <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16, gap: 16 }}>
    <Text style={styles.heading}>Share a moment ✨</Text>
    <Text style={styles.subtitle}>Tell your people what is happening.</Text>
    <TextInput value={caption} onChangeText={setCaption} style={[styles.input, styles.multiline]} placeholder="Write a caption..." multiline textAlignVertical="top" />
    <Pressable style={styles.secondaryButton} onPress={chooseImage}><Text style={styles.secondaryButtonText}>{image ? 'Choose a different photo' : '＋ Choose a photo'}</Text></Pressable>
    {image && <Image source={{ uri: image.uri }} style={styles.preview} resizeMode="cover" />}
    <Pressable style={[styles.button, busy && { opacity: 0.6 }]} disabled={busy} onPress={publish}><Text style={styles.buttonText}>{busy ? 'Publishing…' : 'Publish post'}</Text></Pressable>
    <Text style={styles.smallNote}>Uploaded images use the Supabase Storage bucket configured in the project setup.</Text>
  </ScrollView>;
}
