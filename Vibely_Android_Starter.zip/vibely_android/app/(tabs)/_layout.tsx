import { Tabs } from 'expo-router';
import { Text } from 'react-native';

function TabIcon({ label, focused }: { label: string; focused: boolean }) {
  return <Text style={{ fontSize: 11, fontWeight: focused ? '700' : '500', color: focused ? '#6D42D8' : '#81788F' }}>{label}</Text>;
}

export default function TabsLayout() {
  return (
    <Tabs screenOptions={{
      headerStyle: { backgroundColor: '#FFFFFF' },
      headerTintColor: '#21163C',
      headerTitleStyle: { fontWeight: '800' },
      tabBarActiveTintColor: '#6D42D8',
      tabBarInactiveTintColor: '#81788F',
      tabBarStyle: { height: 62, paddingBottom: 8, paddingTop: 8 },
    }}>
      <Tabs.Screen name="feed" options={{ title: 'Vibely', tabBarLabel: 'Feed', tabBarIcon: ({ focused }) => <TabIcon label="⌂" focused={focused} /> }} />
      <Tabs.Screen name="compose" options={{ title: 'Create a post', tabBarLabel: 'Post', tabBarIcon: ({ focused }) => <TabIcon label="＋" focused={focused} /> }} />
      <Tabs.Screen name="inbox" options={{ title: 'Messages', tabBarLabel: 'Chat', tabBarIcon: ({ focused }) => <TabIcon label="☏" focused={focused} /> }} />
      <Tabs.Screen name="profile" options={{ title: 'Your profile', tabBarLabel: 'Profile', tabBarIcon: ({ focused }) => <TabIcon label="◉" focused={focused} /> }} />
    </Tabs>
  );
}
