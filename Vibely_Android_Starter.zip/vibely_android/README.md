# Vibely — Android social app starter

A React Native + Expo Router app with Supabase Auth, photo posts, feed likes, profiles, and direct private messaging.

**Important:** this is a starter project. It becomes a real connected app after you create your Supabase project, run the SQL setup, add your project keys, and test it. It is not yet a signed APK or Play Store release.

## What you need

- A computer for the easiest professional build workflow (Windows, macOS, or Linux).
- Node.js LTS and npm.
- A free Supabase project.
- An Android phone with Expo Go for early testing.
- For Play Store release: an Expo/EAS account and a Google Play Console developer account.

You can read this on your Android phone, but building and packaging the project is substantially easier on a computer. If you only have your phone, you may need a cloud development environment.

## 1. Create the backend

1. Create a project at https://supabase.com/.
2. In the Supabase dashboard, open **SQL Editor**.
3. Open `supabase/schema.sql` from this project, copy its full contents into a new SQL query, and run it.
4. In **Project Settings → API** (or the project's API keys page), copy the Project URL and the publishable/anon key. Never use the `service_role` secret key in a mobile app.
5. In **Authentication → URL Configuration**, configure your app's auth settings as needed. For early email/password testing, you can use Supabase's default email confirmation behavior.

The SQL creates the profiles, posts, likes, conversations, members, messages tables, row-level security policies, a post image bucket, and a profile-on-signup trigger.

## 2. Configure the app

1. Copy `.env.example` to a file named `.env` in the project root.
2. Replace the values with your Supabase URL and publishable/anon key:

   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
   ```

3. Do not commit `.env` to a public repository. The anon/publishable key is intended for client apps when Row Level Security is correctly configured; the service-role key is never safe to ship.

## 3. Install and run

Install Node.js LTS from https://nodejs.org/ and then, in a terminal inside the project folder:

```bash
npm install
npx expo start
```

Install **Expo Go** from Google Play Store on your Android phone. Make sure your phone and computer are on the same Wi-Fi network, scan the QR code in the terminal/browser with Expo Go, and open the project.

If your network blocks LAN discovery, try:

```bash
npx expo start --tunnel
```

## 4. First test checklist

- Sign up with an email you can access and a password of at least 8 characters.
- Confirm your email if Supabase asks you to.
- Sign in.
- Open Profile and save a unique username (3–24 lowercase letters, numbers, or underscores).
- Open Post, write a caption, choose a photo, and publish.
- Open Feed and test likes.
- Create a second account on another device, set its username, and test the feed.
- Test chat between the two accounts after the chat UI's platform-specific new-chat input is implemented/verified.

## 5. Build an installable Android APK

Once it works in Expo Go:

1. Create an Expo account at https://expo.dev/.
2. Install EAS CLI:

   ```bash
   npm install -g eas-cli
   eas login
   eas build:configure
   ```

3. Create `eas.json` in the project root with:

   ```json
   {
     "build": {
       "preview": {
         "distribution": "internal",
         "android": { "buildType": "apk" }
       },
       "production": {
         "android": { "buildType": "app-bundle" }
       }
     }
   }
   ```

4. Build a test APK:

   ```bash
   eas build --platform android --profile preview
   ```

5. When EAS finishes, open the build link on your Android phone and install the APK. Android may ask you to allow installs from that browser; only install builds you trust.

For the Play Store, build an Android App Bundle (AAB):

```bash
eas build --platform android --profile production
```

Then upload the `.aab` in Google Play Console and complete the required store listing, privacy policy, data safety form, content rating, testing, and review steps. Play Console registration has generally required a one-time US$25 fee; check the current Play Console rules and testing requirements before launch.

## Included features

- Email/password sign-up and sign-in using Supabase Auth.
- Profile name, username, and bio.
- Photo picker, image upload to Supabase Storage, and caption posts.
- Feed listing and likes.
- Conversation list and realtime message screen.
- Row Level Security policies in `supabase/schema.sql`.

## Known limitations before public launch

- The Android “New chat” username prompt uses `Alert.prompt`, which is not supported on Android; replace it with a dedicated username-search screen/form before relying on it. The conversation list and chat screen are present, and the SQL RPC exists.
- Comment UI and comment database are not yet implemented.
- Public photo URLs mean anyone with a photo URL can view the image. For private photos, use a private bucket and signed URLs.
- Add moderation/report/block features, account deletion, rate limits, robust error handling, privacy policy, terms, accessibility, and testing before a public launch.
- The Realtime publication SQL line can fail if `messages` is already in `supabase_realtime`; if that happens, enable Realtime for `messages` in Supabase Dashboard → Database → Publications instead.
- For a production app, review all database policies with a security professional and test them with multiple user accounts.

## Project layout

```text
app/
  _layout.tsx
  index.tsx
  auth.tsx
  (tabs)/
    _layout.tsx
    feed.tsx
    compose.tsx
    inbox.tsx
    profile.tsx
  chat/[id].tsx
lib/
  supabase.ts
  styles.ts
supabase/
  schema.sql
```
